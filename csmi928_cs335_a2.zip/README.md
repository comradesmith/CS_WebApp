# CS 335 - Assignment 2
Making a responsive web application in vanilla javascript to display 
content from UoA's rest services.

Author: Cam Smith - csmi928 - 706899195
